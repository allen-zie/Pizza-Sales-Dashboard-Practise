
select Sum(total_price) as TOTAL_REVENUE from pizza_sales
