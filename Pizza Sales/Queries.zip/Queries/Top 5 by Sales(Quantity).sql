select * from pizza_sales

select Top 5 pizza_name, SUM(quantity) AS Total_Sales
from pizza_sales
GROUP BY pizza_name
ORDER BY Total_Sales desc