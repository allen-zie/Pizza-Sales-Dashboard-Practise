select * from pizza_sales

select COUNT(DISTINCT order_id) AS Total_Orders from pizza_sales 