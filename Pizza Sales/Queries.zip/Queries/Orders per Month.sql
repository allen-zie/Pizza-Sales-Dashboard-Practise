select * from pizza_sales

select DATENAME(MONTH, order_date) AS Order_Month, COUNT(DISTINCT order_id) AS Total_Order from pizza_sales
GROUP BY DATENAME(MONTH, order_date)
ORDER by Order_Month DESC