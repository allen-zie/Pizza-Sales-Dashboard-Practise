SELECT * FROM pizza_sales

SELECT pizza_category, sum(total_price) * 100 / (SELECT sum(total_price) from pizza_sales AS Total_Percental_Sales)
from pizza_sales 
GROUP BY pizza_category