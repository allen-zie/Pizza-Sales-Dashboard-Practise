select * from pizza_sales

SELECT pizza_category, 
CAST(SUM(total_price) AS DECIMAL(10,2)) as Total_Revenue,
CAST(SUM(total_price) * 100 / (SELECT SUM(total_price) FROM pizza_sales) 
AS DECIMAL(10,2)) AS Percental_Sale_Category
FROM pizza_sales
GROUP BY pizza_category