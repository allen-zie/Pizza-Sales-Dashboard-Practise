select * from pizza_sales

select DATENAME(DW, order_date) AS order_day, COUNT(DISTINCT order_id) AS Total_order from pizza_sales
GROUP BY DATENAME(DW, order_date)