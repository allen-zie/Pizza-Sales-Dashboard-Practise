select * from pizza_sales

select Top 5 pizza_name, SUM(total_price) as Total_Revenue
from pizza_sales
GROUP BY pizza_name
ORDER BY Total_Revenue Asc