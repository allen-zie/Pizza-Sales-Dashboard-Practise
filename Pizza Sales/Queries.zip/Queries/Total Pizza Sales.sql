select * from pizza_sales
SELECT SUM(quantity) AS TOTAL_SALES FROM pizza_sales